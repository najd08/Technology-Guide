package com.example.technologysystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechnologySystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechnologySystemApplication.class, args);
	}

}
