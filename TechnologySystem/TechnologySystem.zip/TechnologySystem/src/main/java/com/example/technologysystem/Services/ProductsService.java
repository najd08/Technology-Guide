package com.example.technologysystem.Services;

import com.example.technologysystem.Exception.ApiException;
import com.example.technologysystem.Model.Products;
import com.example.technologysystem.Repository.ProductsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductsService {
    private final ProductsRepository productsRepository;
    public List<Products> getProducts(){ return productsRepository.findAll();}
    public void addProducts(Products products){

        productsRepository.save(products);}
    public void updateProducts(Integer id, Products products){
        Products oldProduct= productsRepository.findProductsById(id);
        if (oldProduct==null)
            throw new ApiException("no ID was found!");
        oldProduct.setCategory(products.getCategory());
        oldProduct.setName(products.getName());
        oldProduct.setUsage(products.getUsage());
        productsRepository.save(oldProduct);
    }
    public void deleteProducts(Integer id){
        Products products=productsRepository.findProductsById(id);
        if (products==null)
            throw new ApiException("Wrong ID!");
        productsRepository.delete(products);
    }

}
